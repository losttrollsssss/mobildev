package com.example.randomfilmk

 data class Movie (val name: String, val year: Int, val rating: Float) {

}