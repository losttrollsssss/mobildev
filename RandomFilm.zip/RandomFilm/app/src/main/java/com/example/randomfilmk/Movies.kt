package com.example.randomfilmk

data class Movies (val movies: Array<Movie>) {

}